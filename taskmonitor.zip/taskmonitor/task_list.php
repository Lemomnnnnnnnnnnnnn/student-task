<?php
include "includes/config.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$username = $_SESSION['username'];

$task_conn = new mysqli("localhost", "root", "", "task_manager_system");
if ($task_conn->connect_error) die("Connection failed: " . $task_conn->connect_error);

$allowed_sort = ['title', 'category', 'priority', 'due_date', 'status', 'created_at'];
$sort_col = in_array($_GET['sort'] ?? '', $allowed_sort) ? $_GET['sort'] : 'due_date';
$sort_dir = strtoupper($_GET['dir'] ?? 'ASC') === 'DESC' ? 'DESC' : 'ASC';
$flip_dir = $sort_dir === 'ASC' ? 'DESC' : 'ASC';

$stmt = $task_conn->query("
    SELECT *, DATEDIFF(CURDATE(), due_date) AS days_overdue
    FROM tasks
    ORDER BY $sort_col $sort_dir
");

$total     = $task_conn->query("SELECT COUNT(*) AS c FROM tasks")->fetch_assoc()['c'];
$completed = $task_conn->query("SELECT COUNT(*) AS c FROM tasks WHERE status='Completed'")->fetch_assoc()['c'];
$pct = $total > 0 ? round($completed / $total * 100) : 0;

function priority_badge($p) {
    $map = ['High' => '#e74c3c', 'Medium' => '#f39c12', 'Low' => '#27ae60'];
    $color = $map[$p] ?? '#7f8c8d';
    return "<span class='badge' style='background:$color'>$p</span>";
}
function status_badge($s) {
    $map = ['Completed' => '#27ae60', 'In Progress' => '#2980b9', 'Pending' => '#7f8c8d'];
    $color = $map[$s] ?? '#7f8c8d';
    return "<span class='badge' style='background:$color'>$s</span>";
}
function sort_link($col, $label, $current, $dir, $flip) {
    $arrow = $current === $col ? ($dir === 'ASC' ? ' ↑' : ' ↓') : '';
    return "<a href='task_list.php?sort=$col&dir=" . ($current === $col ? $flip : 'ASC') . "' class='sort-link'>$label$arrow</a>";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Tasks | Student To-Do List</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <script src="assets/js/theme.js"></script>
</head>
<body>
<div class="layout">

    <aside class="sidebar">
        <div class="sidebar-logo">
            <span class="logo-icon">📚</span>
            <span class="logo-text">To-Do List</span>
        </div>
        <nav class="sidebar-nav">
            <a href="dashboard.php" class="nav-link">
                <span class="nav-icon">🏠</span> Dashboard
            </a>
            <a href="task_list.php" class="nav-link active">
                <span class="nav-icon">📋</span> All Tasks
            </a>
            <a href="search_task.php" class="nav-link">
                <span class="nav-icon">🔍</span> Search Tasks
            </a>
            <a href="filter_task.php" class="nav-link">
                <span class="nav-icon">⚙️</span> Filter Tasks
            </a>
        </nav>
        <a href="logout.php" class="sidebar-logout">🚪 Logout</a>
    </aside>

    <div class="main-content">

        <header class="topbar">
            <div>
                <h1 class="page-title">All Tasks</h1>
                <p class="page-date"><?= date("l, d F Y") ?></p>
            </div>
            <div class="topbar-right">
                <button class="theme-toggle" onclick="toggleTheme()" title="Toggle dark mode">🌙</button>
                <div class="user-badge">👋 <strong><?= htmlspecialchars($username) ?></strong></div>
            </div>
        </header>

        <div class="progress-card">
            <div class="progress-meta">
                <span>Overall Progress</span>
                <span><strong><?= $completed ?></strong> of <strong><?= $total ?></strong> tasks completed</span>
            </div>
            <div class="progress-track">
                <div class="progress-fill" style="width:<?= $pct ?>%"></div>
            </div>
            <div class="progress-pct"><?= $pct ?>%</div>
        </div>

        <div class="table-actions">
            <a href="search_task.php" class="btn-secondary">🔍 Search</a>
            <a href="filter_task.php" class="btn-secondary">⚙️ Filter</a>
        </div>

        <div class="table-wrap">
            <table class="task-table">
                <thead>
                    <tr>
                        <th><?= sort_link('title',      'Title',      $sort_col, $sort_dir, $flip_dir) ?></th>
                        <th><?= sort_link('category',   'Category',   $sort_col, $sort_dir, $flip_dir) ?></th>
                        <th><?= sort_link('priority',   'Priority',   $sort_col, $sort_dir, $flip_dir) ?></th>
                        <th><?= sort_link('created_at', 'Start Date', $sort_col, $sort_dir, $flip_dir) ?></th>
                        <th><?= sort_link('due_date',   'Due Date',   $sort_col, $sort_dir, $flip_dir) ?></th>
                        <th><?= sort_link('status',     'Status',     $sort_col, $sort_dir, $flip_dir) ?></th>
                    </tr>
                </thead>
                <tbody>
                <?php while ($row = $stmt->fetch_assoc()):
                    $days_over = intval($row['days_overdue']);
                    $row_class = ($days_over > 5) ? 'row-critical' : ($days_over > 0 ? 'row-overdue' : '');
                ?>
                    <tr class="<?= $row_class ?>">
                        <td class="task-title">
                            <?= htmlspecialchars($row['title']) ?>
                            <?php if ($days_over > 5): ?>
                                <span class="overdue-tag">🔴 <?= $days_over ?>d overdue</span>
                            <?php elseif ($days_over > 0): ?>
                                <span class="overdue-tag-mild">⚠️ <?= $days_over ?>d overdue</span>
                            <?php endif; ?>
                        </td>
                        <td><?= htmlspecialchars($row['category']) ?></td>
                        <td><?= priority_badge($row['priority']) ?></td>
                        <td class="date-cell">
                            <?= isset($row['created_at']) ? date("d M Y", strtotime($row['created_at'])) : '—' ?>
                        </td>
                        <td class="date-cell <?= $days_over > 5 ? 'date-critical' : ($days_over > 0 ? 'date-overdue' : '') ?>">
                            <?= date("d M Y", strtotime($row['due_date'])) ?>
                        </td>
                        <td><?= status_badge($row['status']) ?></td>
                    </tr>
                <?php endwhile; ?>
                </tbody>
            </table>
        </div>

    </div>
</div>
</body>
</html>
